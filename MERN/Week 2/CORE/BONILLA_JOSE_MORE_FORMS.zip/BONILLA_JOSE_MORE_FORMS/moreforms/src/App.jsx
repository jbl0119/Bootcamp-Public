import './App.css'
import MoreForms from './components/MoreForms'

function App() {

  return (
    <>
      <MoreForms />
    </>
  )
  
}



export default App
