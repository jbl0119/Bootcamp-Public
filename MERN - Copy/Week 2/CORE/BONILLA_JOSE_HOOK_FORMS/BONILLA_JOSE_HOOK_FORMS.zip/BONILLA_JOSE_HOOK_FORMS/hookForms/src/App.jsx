import './App.css'
import HookForms from './components/HookForms'

function App() {

  return (
    <>
      <HookForms />
    </>
  )
  
}



export default App
